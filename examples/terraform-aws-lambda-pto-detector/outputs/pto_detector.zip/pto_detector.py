def hello(event, context):
    print("Welome to terraform")