def main_handler(event, context):
    print("Welome to terraform")