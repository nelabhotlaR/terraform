def (hello_event, context)
    print("Welome to terraform")